import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Consultoria table - stores each consultation session
 */
export const consultations = mysqlTable("consultations", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  consultationName: varchar("consultationName", { length: 255 }).notNull(),
  status: mysqlEnum("status", ["in_progress", "completed", "archived"]).default("in_progress").notNull(),
  
  // Business data
  website: text("website"),
  productService: text("productService"),
  campaignObjective: varchar("campaignObjective", { length: 64 }), // sales, leads, whatsapp
  ticketAverage: int("ticketAverage"),
  profitMargin: int("profitMargin"),
  location: varchar("location", { length: 255 }),
  targetAudience: text("targetAudience"),
  mainPain: text("mainPain"),
  whatsappNumber: varchar("whatsappNumber", { length: 20 }),
  dailyBudget: int("dailyBudget"),
  
  // Strategy data (JSON)
  strategy: text("strategy"), // JSON stringified strategy
  diagnosis: text("diagnosis"), // JSON stringified diagnosis
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Consultation = typeof consultations.$inferSelect;
export type InsertConsultation = typeof consultations.$inferInsert;

/**
 * Consultation responses table - stores individual question responses
 */
export const consultationResponses = mysqlTable("consultationResponses", {
  id: int("id").autoincrement().primaryKey(),
  consultationId: int("consultationId").notNull().references(() => consultations.id),
  questionKey: varchar("questionKey", { length: 255 }).notNull(),
  answer: text("answer"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ConsultationResponse = typeof consultationResponses.$inferSelect;
export type InsertConsultationResponse = typeof consultationResponses.$inferInsert;