CREATE TABLE `consultationResponses` (
	`id` int AUTO_INCREMENT NOT NULL,
	`consultationId` int NOT NULL,
	`questionKey` varchar(255) NOT NULL,
	`answer` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `consultationResponses_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `consultations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`consultationName` varchar(255) NOT NULL,
	`status` enum('in_progress','completed','archived') NOT NULL DEFAULT 'in_progress',
	`website` text,
	`productService` text,
	`campaignObjective` varchar(64),
	`ticketAverage` int,
	`profitMargin` int,
	`location` varchar(255),
	`targetAudience` text,
	`mainPain` text,
	`whatsappNumber` varchar(20),
	`dailyBudget` int,
	`strategy` text,
	`diagnosis` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `consultations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `consultationResponses` ADD CONSTRAINT `consultationResponses_consultationId_consultations_id_fk` FOREIGN KEY (`consultationId`) REFERENCES `consultations`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `consultations` ADD CONSTRAINT `consultations_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;