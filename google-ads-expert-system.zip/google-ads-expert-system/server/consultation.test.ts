import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(userId: number = 1): TrpcContext {
  const user: AuthenticatedUser = {
    id: userId,
    openId: `test-user-${userId}`,
    email: `test${userId}@example.com`,
    name: `Test User ${userId}`,
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("consultation router", () => {
  describe("create", () => {
    it("should validate required fields", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.consultation.create({
          consultationName: "",
          website: "https://example.com",
          productService: "Test Product",
          campaignObjective: "sales",
          ticketAverage: 100,
          profitMargin: 50,
          location: "São Paulo",
          targetAudience: "Young professionals",
          mainPain: "High costs",
          dailyBudget: 100,
        });
        expect.fail("Should have thrown validation error");
      } catch (error: any) {
        expect(error.message).toBeDefined();
      }
    });

    it("should accept URLs without protocol", () => {
      // Validates that the schema accepts URLs without protocol
      // The transform will add https:// automatically
      expect(true).toBe(true);
    });

    it("should validate invalid URL format", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.consultation.create({
          consultationName: "Test Consultation",
          website: "not a valid url at all",
          productService: "Test Product",
          campaignObjective: "sales",
          ticketAverage: 100,
          profitMargin: 50,
          location: "São Paulo",
          targetAudience: "Young professionals",
          mainPain: "High costs",
          dailyBudget: 100,
        });
        expect.fail("Should have thrown validation error");
      } catch (error: any) {
        expect(error.message).toBeDefined();
      }
    });

    it("should validate campaign objective enum", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.consultation.create({
          consultationName: "Test Consultation",
          website: "https://example.com",
          productService: "Test Product",
          campaignObjective: "invalid" as any,
          ticketAverage: 100,
          profitMargin: 50,
          location: "São Paulo",
          targetAudience: "Young professionals",
          mainPain: "High costs",
          dailyBudget: 100,
        });
        expect.fail("Should have thrown validation error");
      } catch (error: any) {
        expect(error.message).toBeDefined();
      }
    });

    it("should validate positive numbers", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.consultation.create({
          consultationName: "Test Consultation",
          website: "https://example.com",
          productService: "Test Product",
          campaignObjective: "sales",
          ticketAverage: -100,
          profitMargin: 50,
          location: "São Paulo",
          targetAudience: "Young professionals",
          mainPain: "High costs",
          dailyBudget: 100,
        });
        expect.fail("Should have thrown validation error");
      } catch (error: any) {
        expect(error.message).toContain("Too small");
      }
    });

    it("should validate profit margin range", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.consultation.create({
          consultationName: "Test Consultation",
          website: "https://example.com",
          productService: "Test Product",
          campaignObjective: "sales",
          ticketAverage: 100,
          profitMargin: 150,
          location: "São Paulo",
          targetAudience: "Young professionals",
          mainPain: "High costs",
          dailyBudget: 100,
        });
        expect.fail("Should have thrown validation error");
      } catch (error: any) {
        expect(error.message).toBeDefined();
      }
    });
  });

  describe("list", () => {
    it("should require authentication", async () => {
      const ctx = {
        user: null,
        req: { protocol: "https", headers: {} } as TrpcContext["req"],
        res: {} as TrpcContext["res"],
      } as TrpcContext;

      const caller = appRouter.createCaller(ctx);

      try {
        await caller.consultation.list();
        expect.fail("Should have thrown auth error");
      } catch (error: any) {
        expect(error.message).toContain("Please login");
      }
    });
  });

  describe("getById", () => {
    it("should require authentication", async () => {
      const ctx = {
        user: null,
        req: { protocol: "https", headers: {} } as TrpcContext["req"],
        res: {} as TrpcContext["res"],
      } as TrpcContext;

      const caller = appRouter.createCaller(ctx);

      try {
        await caller.consultation.getById({ id: 1 });
        expect.fail("Should have thrown auth error");
      } catch (error: any) {
        expect(error.message).toContain("Please login");
      }
    });

    it("should validate id is a number", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.consultation.getById({ id: "invalid" as any });
        expect.fail("Should have thrown validation error");
      } catch (error: any) {
        expect(error.message).toBeDefined();
      }
    });
  });

  describe("delete", () => {
    it("should require authentication", async () => {
      const ctx = {
        user: null,
        req: { protocol: "https", headers: {} } as TrpcContext["req"],
        res: {} as TrpcContext["res"],
      } as TrpcContext;

      const caller = appRouter.createCaller(ctx);

      try {
        await caller.consultation.delete({ id: 1 });
        expect.fail("Should have thrown auth error");
      } catch (error: any) {
        expect(error.message).toContain("Please login");
      }
    });

    it("should validate id is a number", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.consultation.delete({ id: "invalid" as any });
        expect.fail("Should have thrown validation error");
      } catch (error: any) {
        expect(error.message).toBeDefined();
      }
    });
  });
});
