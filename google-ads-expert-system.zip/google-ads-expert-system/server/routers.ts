import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { getDb, getUserByOpenId } from "./db";
import { z } from "zod";
import { consultations, consultationResponses } from "../drizzle/schema";
import { eq } from "drizzle-orm";
import { invokeLLM } from "./_core/llm";
import { notifyOwner } from "./_core/notification";
import { generateConsultationPDF, generateConsultationText } from "./pdf-export";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  consultation: router({
    create: protectedProcedure
      .input(
        z.object({
          consultationName: z.string().min(1),
          website: z.string().min(1).transform((url) => {
            // Add https:// if no protocol is provided
            if (!url.startsWith('http://') && !url.startsWith('https://')) {
              return `https://${url}`;
            }
            return url;
          }).pipe(z.string().url()),
          productService: z.string().min(1),
          campaignObjective: z.enum(["sales", "leads", "whatsapp"]),
          ticketAverage: z.number().positive(),
          profitMargin: z.number().min(0).max(100),
          location: z.string().min(1),
          targetAudience: z.string().min(1),
          mainPain: z.string().min(1),
          whatsappNumber: z.string().optional(),
          dailyBudget: z.number().positive(),
          creatives: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        try {
          // Insert consultation
          await db.insert(consultations).values({
            userId: ctx.user.id,
            consultationName: input.consultationName,
            website: input.website,
            productService: input.productService,
            campaignObjective: input.campaignObjective,
            ticketAverage: input.ticketAverage,
            profitMargin: input.profitMargin,
            location: input.location,
            targetAudience: input.targetAudience,
            mainPain: input.mainPain,
            whatsappNumber: input.whatsappNumber || null,
            dailyBudget: input.dailyBudget,
            status: "completed",
          });

          // Get the created consultation
          const created = await db
            .select()
            .from(consultations)
            .where(eq(consultations.userId, ctx.user.id))
            .orderBy((t) => t.id)
            .limit(1);

          if (created.length === 0) throw new Error("Failed to create consultation");
          const consultationId = created[0].id;

          // Generate diagnosis and strategy using LLM
          const diagnosis = await generateDiagnosis(input);
          const strategy = await generateStrategy(input, diagnosis);

          // Update consultation with strategy and diagnosis
          await db
            .update(consultations)
            .set({
              diagnosis: JSON.stringify(diagnosis),
              strategy: JSON.stringify(strategy),
            })
            .where(eq(consultations.id, Number(consultationId)));

          // Notify owner
          await notifyOwner({
            title: "Nova Consultoria Completada",
            content: `Uma nova consultoria foi gerada: ${input.consultationName}. Objetivo: ${input.campaignObjective}`,
          });

          return {
            id: Number(consultationId),
            consultationName: input.consultationName,
            status: "completed",
            diagnosis,
            strategy,
          };
        } catch (error) {
          console.error("[Consultation Create Error]", error);
          throw error;
        }
      }),

    list: protectedProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) return [];

      try {
        const userConsultations = await db
          .select()
          .from(consultations)
          .where(eq(consultations.userId, ctx.user.id));

        return userConsultations.map((c) => ({
          id: c.id,
          consultationName: c.consultationName,
          productService: c.productService,
          status: c.status,
          campaignObjective: c.campaignObjective,
          createdAt: c.createdAt,
        }));
      } catch (error) {
        console.error("[Consultation List Error]", error);
        return [];
      }
    }),

    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) return null;

        try {
          const consultation = await db
            .select()
            .from(consultations)
            .where(eq(consultations.id, input.id))
            .limit(1);

          if (
            consultation.length === 0 ||
            consultation[0].userId !== ctx.user.id
          ) {
            return null;
          }

          const data = consultation[0];
          return {
            id: data.id,
            consultationName: data.consultationName,
            website: data.website,
            productService: data.productService,
            campaignObjective: data.campaignObjective,
            ticketAverage: data.ticketAverage,
            profitMargin: data.profitMargin,
            location: data.location,
            targetAudience: data.targetAudience,
            mainPain: data.mainPain,
            whatsappNumber: data.whatsappNumber,
            dailyBudget: data.dailyBudget,
            status: data.status,
            diagnosis: data.diagnosis ? JSON.parse(data.diagnosis) : null,
            strategy: data.strategy ? JSON.parse(data.strategy) : null,
            createdAt: data.createdAt,
          };
        } catch (error) {
          console.error("[Consultation GetById Error]", error);
          return null;
        }
      }),

    exportPDF: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        try {
          const consultation = await db
            .select()
            .from(consultations)
            .where(eq(consultations.id, input.id))
            .limit(1);

          if (
            consultation.length === 0 ||
            consultation[0].userId !== ctx.user.id
          ) {
            throw new Error("Unauthorized");
          }

          const data = consultation[0];
          const pdfBuffer = await generateConsultationPDF({
            ...data,
            diagnosis: data.diagnosis ? JSON.parse(data.diagnosis) : null,
            strategy: data.strategy ? JSON.parse(data.strategy) : null,
          });

          return {
            success: true,
            buffer: pdfBuffer.toString("base64"),
            filename: `consultoria-${data.consultationName.replace(/\s+/g, "-")}.pdf`,
          };
        } catch (error) {
          console.error("[PDF Export Error]", error);
          throw error;
        }
      }),

    exportText: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        try {
          const consultation = await db
            .select()
            .from(consultations)
            .where(eq(consultations.id, input.id))
            .limit(1);

          if (
            consultation.length === 0 ||
            consultation[0].userId !== ctx.user.id
          ) {
            throw new Error("Unauthorized");
          }

          const data = consultation[0];
          const textContent = await generateConsultationText({
            ...data,
            diagnosis: data.diagnosis ? JSON.parse(data.diagnosis) : null,
            strategy: data.strategy ? JSON.parse(data.strategy) : null,
          });

          return {
            success: true,
            content: textContent,
            filename: `consultoria-${data.consultationName.replace(/\s+/g, "-")}.txt`,
          };
        } catch (error) {
          console.error("[Text Export Error]", error);
          throw error;
        }
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        try {
          // Verify ownership
          const consultation = await db
            .select()
            .from(consultations)
            .where(eq(consultations.id, input.id))
            .limit(1);

          if (
            consultation.length === 0 ||
            consultation[0].userId !== ctx.user.id
          ) {
            throw new Error("Unauthorized");
          }

          // Delete related responses
          await db
            .delete(consultationResponses)
            .where(eq(consultationResponses.consultationId, input.id));

          // Delete consultation
          await db.delete(consultations).where(eq(consultations.id, input.id));

          return { success: true };
        } catch (error) {
          console.error("[Consultation Delete Error]", error);
          throw error;
        }
      }),
  }),
});

/**
 * Generate diagnosis using LLM
 */
async function generateDiagnosis(input: {
  productService: string;
  campaignObjective: string;
  ticketAverage: number;
  profitMargin: number;
  location: string;
  targetAudience: string;
  mainPain: string;
}) {
  const prompt = `
Você é um consultor sênior de Google Ads com 10+ anos de experiência.

Analise os seguintes dados de negócio e forneça um diagnóstico estratégico:

Produto/Serviço: ${input.productService}
Objetivo: ${input.campaignObjective}
Ticket Médio: R$ ${input.ticketAverage}
Margem de Lucro: ${input.profitMargin}%
Localização: ${input.location}
Público-Alvo: ${input.targetAudience}
Dor Principal: ${input.mainPain}

Forneça uma resposta JSON com:
{
  "businessType": "tipo de negócio identificado",
  "awarenessLevel": "nível de consciência do público (low/medium/high)",
  "recommendedCampaignType": "tipo de campanha recomendado",
  "explanation": "explicação clara do porquê dessa recomendação",
  "keyInsights": ["insight 1", "insight 2", "insight 3"]
}
`;

  const response = await invokeLLM({
    messages: [
      {
        role: "system" as const,
        content:
          "Você é um especialista em Google Ads. Sempre responda em JSON válido.",
      },
      { role: "user" as const, content: prompt },
    ],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "diagnosis",
        strict: true,
        schema: {
          type: "object",
          properties: {
            businessType: { type: "string" },
            awarenessLevel: { type: "string" },
            recommendedCampaignType: { type: "string" },
            explanation: { type: "string" },
            keyInsights: {
              type: "array",
              items: { type: "string" },
            },
          },
          required: [
            "businessType",
            "awarenessLevel",
            "recommendedCampaignType",
            "explanation",
            "keyInsights",
          ],
          additionalProperties: false,
        },
      },
    },
  });

  try {
    const content = response.choices[0]?.message?.content;
    if (!content) throw new Error("No response from LLM");
    const contentStr = typeof content === "string" ? content : JSON.stringify(content);
    return JSON.parse(contentStr);
  } catch (error) {
    console.error("[Diagnosis Generation Error]", error);
    return {
      businessType: "E-commerce/Serviço",
      awarenessLevel: "medium",
      recommendedCampaignType: "Search",
      explanation:
        "Baseado nos dados fornecidos, recomendamos campanhas de Pesquisa para capturar intenção de compra.",
      keyInsights: [
        "Foco em palavras-chave de fundo de funil",
        "Otimização para conversões",
        "Segmentação por localização",
      ],
    };
  }
}

/**
 * Generate strategy using LLM
 */
async function generateStrategy(
  input: {
    productService: string;
    campaignObjective: string;
    ticketAverage: number;
    profitMargin: number;
    location: string;
    targetAudience: string;
    mainPain: string;
    dailyBudget: number;
  },
  diagnosis: any
) {
  const prompt = `
Você é um consultor sênior de Google Ads.

Com base no diagnóstico: ${JSON.stringify(diagnosis)}

E nos dados do negócio:
- Produto: ${input.productService}
- Objetivo: ${input.campaignObjective}
- Ticket: R$ ${input.ticketAverage}
- Margem: ${input.profitMargin}%
- Público: ${input.targetAudience}
- Dor: ${input.mainPain}
- Orçamento Diário: R$ ${input.dailyBudget}

Gere uma estratégia completa de Google Ads em JSON com:
{
  "campaignType": "tipo de campanha",
  "bidStrategy": "estratégia de lance",
  "dailyBudget": número,
  "numberOfCampaigns": número,
  "numberOfAdGroups": número,
  "keywordMatch": "tipo de correspondência",
  "primaryKeywords": ["palavra-chave 1", "palavra-chave 2", ...],
  "secondaryKeywords": ["palavra-chave 3", ...],
  "negativeKeywords": ["palavra negativa 1", ...],
  "adTitles": ["título 1", "título 2", "título 3"],
  "adDescriptions": ["descrição 1", "descrição 2"],
  "ctas": ["CTA 1", "CTA 2", "CTA 3"],
  "extensions": ["extensão 1", "extensão 2", "extensão 3"],
  "explanation": "explicação da estratégia"
}
`;

  const response = await invokeLLM({
    messages: [
      {
        role: "system" as const,
        content:
          "Você é um especialista em Google Ads. Sempre responda em JSON válido.",
      },
      { role: "user" as const, content: prompt },
    ],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "strategy",
        strict: true,
        schema: {
          type: "object",
          properties: {
            campaignType: { type: "string" },
            bidStrategy: { type: "string" },
            dailyBudget: { type: "number" },
            numberOfCampaigns: { type: "number" },
            numberOfAdGroups: { type: "number" },
            keywordMatch: { type: "string" },
            primaryKeywords: { type: "array", items: { type: "string" } },
            secondaryKeywords: { type: "array", items: { type: "string" } },
            negativeKeywords: { type: "array", items: { type: "string" } },
            adTitles: { type: "array", items: { type: "string" } },
            adDescriptions: { type: "array", items: { type: "string" } },
            ctas: { type: "array", items: { type: "string" } },
            extensions: { type: "array", items: { type: "string" } },
            explanation: { type: "string" },
          },
          required: [
            "campaignType",
            "bidStrategy",
            "dailyBudget",
            "numberOfCampaigns",
            "numberOfAdGroups",
            "keywordMatch",
            "primaryKeywords",
            "secondaryKeywords",
            "negativeKeywords",
            "adTitles",
            "adDescriptions",
            "ctas",
            "extensions",
            "explanation",
          ],
          additionalProperties: false,
        },
      },
    },
  });

  try {
    const content = response.choices[0]?.message?.content;
    if (!content) throw new Error("No response from LLM");
    const contentStr = typeof content === "string" ? content : JSON.stringify(content);
    return JSON.parse(contentStr);
  } catch (error) {
    console.error("[Strategy Generation Error]", error);
    return {
      campaignType: "Search",
      bidStrategy: "Maximizar Conversões",
      dailyBudget: input.dailyBudget,
      numberOfCampaigns: 2,
      numberOfAdGroups: 6,
      keywordMatch: "Correspondência Ampla Modificada",
      primaryKeywords: [
        `${input.productService} de qualidade`,
        `comprar ${input.productService}`,
        `${input.productService} online`,
      ],
      secondaryKeywords: [`${input.productService} barato`, `${input.productService} melhor`],
      negativeKeywords: ["grátis", "pirata", "desconto extremo"],
      adTitles: [
        `${input.productService} | Qualidade Garantida`,
        `Compre ${input.productService} | Melhor Preço`,
      ],
      adDescriptions: [
        `Encontre os melhores ${input.productService}. Entrega rápida para todo Brasil.`,
      ],
      ctas: ["Compre Agora", "Confira", "Aproveite"],
      extensions: ["Chamada", "Destaques", "Sitelinks"],
      explanation:
        "Estratégia otimizada para seu tipo de negócio com foco em conversões.",
    };
  }
}

export type AppRouter = typeof appRouter;
