import { PDFDocument, PDFPage, rgb } from "pdf-lib";
import type { Consultation } from "../drizzle/schema";

interface StrategyData {
  campaignType: string;
  bidStrategy: string;
  dailyBudget: number;
  numberOfCampaigns: number;
  numberOfAdGroups: number;
  keywordMatch: string;
  primaryKeywords: string[];
  secondaryKeywords: string[];
  negativeKeywords: string[];
  adTitles: string[];
  adDescriptions: string[];
  ctas: string[];
  extensions: string[];
  explanation: string;
}

interface DiagnosisData {
  businessType: string;
  awarenessLevel: string;
  recommendedCampaignType: string;
  explanation: string;
  keyInsights: string[];
}

export async function generateConsultationPDF(
  consultation: Consultation & {
    diagnosis: DiagnosisData | null;
    strategy: StrategyData | null;
  }
): Promise<Buffer> {
  const pdfDoc = await PDFDocument.create();
  const page = pdfDoc.addPage([595, 842]); // A4 size
  const { width, height } = page.getSize();

  const margin = 40;
  const contentWidth = width - margin * 2;
  let yPosition = height - margin;

  const colors = {
    primary: rgb(0.52, 0.25, 0.18), // Accent color (golden)
    text: rgb(0.11, 0.11, 0.11), // Dark text
    lightText: rgb(0.5, 0.5, 0.5), // Muted text
    border: rgb(0.9, 0.9, 0.9), // Light border
  };

  // Helper function to add text
  const addText = (
    text: string,
    size: number,
    color = colors.text,
    bold = false
  ) => {
    const fontSize = size;
    page.drawText(text, {
      x: margin,
      y: yPosition,
      size: fontSize,
      color,
    });
    yPosition -= fontSize + 8;
  };

  const addHeading = (text: string) => {
    addText(text, 18, colors.primary, true);
    yPosition -= 8;
  };

  const addSubheading = (text: string) => {
    addText(text, 14, colors.text, true);
    yPosition -= 4;
  };

  // Header
  addHeading("CONSULTORIA DE GOOGLE ADS");
  addText(consultation.consultationName, 12, colors.lightText);
  yPosition -= 12;

  // Date
  const date = new Date(consultation.createdAt).toLocaleDateString("pt-BR");
  addText(`Data: ${date}`, 10, colors.lightText);
  yPosition -= 16;

  // Business Info Section
  addSubheading("INFORMAÇÕES DO NEGÓCIO");
  addText(`Produto/Serviço: ${consultation.productService}`, 10);
  addText(`Objetivo: ${consultation.campaignObjective}`, 10);
  addText(`Localização: ${consultation.location}`, 10);
  addText(`Orçamento Diário: R$ ${consultation.dailyBudget}`, 10);
  yPosition -= 12;

  // Diagnosis Section
  if (consultation.diagnosis) {
    addSubheading("DIAGNÓSTICO ESTRATÉGICO");
    addText(`Tipo de Negócio: ${consultation.diagnosis.businessType}`, 10);
    addText(
      `Nível de Consciência: ${consultation.diagnosis.awarenessLevel}`,
      10
    );
    addText(
      `Campanha Recomendada: ${consultation.diagnosis.recommendedCampaignType}`,
      10
    );
    addText(`Análise: ${consultation.diagnosis.explanation}`, 10);

    if (consultation.diagnosis.keyInsights.length > 0) {
      addText("Insights Principais:", 10, colors.text, true);
      consultation.diagnosis.keyInsights.forEach((insight) => {
        addText(`• ${insight}`, 9, colors.lightText);
      });
    }
    yPosition -= 12;
  }

  // Strategy Section
  if (consultation.strategy) {
    addSubheading("ESTRATÉGIA RECOMENDADA");

    addText("Estrutura da Campanha:", 10, colors.text, true);
    addText(`• Tipo: ${consultation.strategy.campaignType}`, 9);
    addText(`• Estratégia de Lance: ${consultation.strategy.bidStrategy}`, 9);
    addText(`• Orçamento: R$ ${consultation.strategy.dailyBudget}`, 9);
    addText(`• Campanhas: ${consultation.strategy.numberOfCampaigns}`, 9);
    addText(`• Grupos de Anúncios: ${consultation.strategy.numberOfAdGroups}`, 9);
    yPosition -= 8;

    addText("Palavras-Chave Principais:", 10, colors.text, true);
    consultation.strategy.primaryKeywords.slice(0, 5).forEach((kw) => {
      addText(`• ${kw}`, 9);
    });
    yPosition -= 8;

    if (consultation.strategy.secondaryKeywords.length > 0) {
      addText("Palavras-Chave Secundárias:", 10, colors.text, true);
      consultation.strategy.secondaryKeywords.slice(0, 3).forEach((kw) => {
        addText(`• ${kw}`, 9);
      });
      yPosition -= 8;
    }

    if (consultation.strategy.negativeKeywords.length > 0) {
      addText("Palavras-Chave Negativas (Evitar):", 10, colors.text, true);
      consultation.strategy.negativeKeywords.slice(0, 3).forEach((kw) => {
        addText(`• ${kw}`, 9);
      });
      yPosition -= 8;
    }

    addText("Anúncios Recomendados:", 10, colors.text, true);
    consultation.strategy.adTitles.slice(0, 2).forEach((title, idx) => {
      addText(`Título ${idx + 1}: ${title}`, 9);
    });
    yPosition -= 8;

    if (consultation.strategy.ctas.length > 0) {
      addText("Chamadas para Ação:", 10, colors.text, true);
      consultation.strategy.ctas.slice(0, 3).forEach((cta) => {
        addText(`• ${cta}`, 9);
      });
      yPosition -= 8;
    }

    addText("Explicação da Estratégia:", 10, colors.text, true);
    addText(consultation.strategy.explanation, 9);
  }

  // Footer
  yPosition = 30;
  addText(
    "Este relatório foi gerado automaticamente pelo Sistema Especialista em Google Ads.",
    8,
    colors.lightText
  );
  addText(
    "Recomendações baseadas em análise de IA e melhores práticas de tráfego pago.",
    8,
    colors.lightText
  );

  const pdfBytes = await pdfDoc.save();
  return Buffer.from(pdfBytes);
}

export async function generateConsultationText(
  consultation: Consultation & {
    diagnosis: DiagnosisData | null;
    strategy: StrategyData | null;
  }
): Promise<string> {
  const date = new Date(consultation.createdAt).toLocaleDateString("pt-BR");
  const lines: string[] = [];

  lines.push("=".repeat(80));
  lines.push("CONSULTORIA DE GOOGLE ADS");
  lines.push("=".repeat(80));
  lines.push("");

  lines.push(`CONSULTORIA: ${consultation.consultationName}`);
  lines.push(`DATA: ${date}`);
  lines.push("");

  lines.push("-".repeat(80));
  lines.push("INFORMAÇÕES DO NEGÓCIO");
  lines.push("-".repeat(80));
  lines.push(`Produto/Serviço: ${consultation.productService}`);
  lines.push(`Objetivo: ${consultation.campaignObjective}`);
  lines.push(`Localização: ${consultation.location}`);
  lines.push(`Ticket Médio: R$ ${consultation.ticketAverage}`);
  lines.push(`Margem de Lucro: ${consultation.profitMargin}%`);
  lines.push(`Orçamento Diário: R$ ${consultation.dailyBudget}`);
  lines.push(`Público-Alvo: ${consultation.targetAudience}`);
  lines.push(`Dor Principal: ${consultation.mainPain}`);
  lines.push("");

  if (consultation.diagnosis) {
    lines.push("-".repeat(80));
    lines.push("DIAGNÓSTICO ESTRATÉGICO");
    lines.push("-".repeat(80));
    lines.push(`Tipo de Negócio: ${consultation.diagnosis.businessType}`);
    lines.push(`Nível de Consciência: ${consultation.diagnosis.awarenessLevel}`);
    lines.push(
      `Campanha Recomendada: ${consultation.diagnosis.recommendedCampaignType}`
    );
    lines.push("");
    lines.push("Análise:");
    lines.push(consultation.diagnosis.explanation);
    lines.push("");

    if (consultation.diagnosis.keyInsights.length > 0) {
      lines.push("Insights Principais:");
      consultation.diagnosis.keyInsights.forEach((insight) => {
        lines.push(`• ${insight}`);
      });
      lines.push("");
    }
  }

  if (consultation.strategy) {
    lines.push("-".repeat(80));
    lines.push("ESTRATÉGIA RECOMENDADA");
    lines.push("-".repeat(80));
    lines.push("");

    lines.push("ESTRUTURA DA CAMPANHA:");
    lines.push(`  Tipo: ${consultation.strategy.campaignType}`);
    lines.push(`  Estratégia de Lance: ${consultation.strategy.bidStrategy}`);
    lines.push(`  Orçamento Diário: R$ ${consultation.strategy.dailyBudget}`);
    lines.push(`  Número de Campanhas: ${consultation.strategy.numberOfCampaigns}`);
    lines.push(
      `  Grupos de Anúncios: ${consultation.strategy.numberOfAdGroups}`
    );
    lines.push(
      `  Correspondência de Palavras: ${consultation.strategy.keywordMatch}`
    );
    lines.push("");

    lines.push("PALAVRAS-CHAVE PRINCIPAIS (FUNDO DE FUNIL):");
    consultation.strategy.primaryKeywords.forEach((kw) => {
      lines.push(`  • ${kw}`);
    });
    lines.push("");

    if (consultation.strategy.secondaryKeywords.length > 0) {
      lines.push("PALAVRAS-CHAVE SECUNDÁRIAS:");
      consultation.strategy.secondaryKeywords.forEach((kw) => {
        lines.push(`  • ${kw}`);
      });
      lines.push("");
    }

    if (consultation.strategy.negativeKeywords.length > 0) {
      lines.push("PALAVRAS-CHAVE NEGATIVAS (EVITAR):");
      consultation.strategy.negativeKeywords.forEach((kw) => {
        lines.push(`  • ${kw}`);
      });
      lines.push("");
    }

    lines.push("TÍTULOS DE ANÚNCIOS:");
    consultation.strategy.adTitles.forEach((title, idx) => {
      lines.push(`  ${idx + 1}. ${title}`);
    });
    lines.push("");

    lines.push("DESCRIÇÕES DE ANÚNCIOS:");
    consultation.strategy.adDescriptions.forEach((desc, idx) => {
      lines.push(`  ${idx + 1}. ${desc}`);
    });
    lines.push("");

    if (consultation.strategy.ctas.length > 0) {
      lines.push("CHAMADAS PARA AÇÃO (CTAs):");
      consultation.strategy.ctas.forEach((cta) => {
        lines.push(`  • ${cta}`);
      });
      lines.push("");
    }

    if (consultation.strategy.extensions.length > 0) {
      lines.push("EXTENSÕES RECOMENDADAS:");
      consultation.strategy.extensions.forEach((ext) => {
        lines.push(`  • ${ext}`);
      });
      lines.push("");
    }

    lines.push("EXPLICAÇÃO DA ESTRATÉGIA:");
    lines.push(consultation.strategy.explanation);
    lines.push("");
  }

  lines.push("=".repeat(80));
  lines.push(
    "Este relatório foi gerado automaticamente pelo Sistema Especialista em Google Ads."
  );
  lines.push(
    "Recomendações baseadas em análise de IA e melhores práticas de tráfego pago."
  );
  lines.push("=".repeat(80));

  return lines.join("\n");
}
