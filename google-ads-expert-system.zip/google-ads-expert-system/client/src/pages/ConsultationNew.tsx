import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Progress } from "@/components/ui/progress";
import { ChevronLeft, ChevronRight, Loader2 } from "lucide-react";
import { useLocation } from "wouter";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

type ConsultationStep = 1 | 2 | 3 | 4;

interface ConsultationData {
  consultationName: string;
  website: string;
  productService: string;
  campaignObjective: "sales" | "leads" | "whatsapp" | "";
  ticketAverage: string;
  profitMargin: string;
  location: string;
  targetAudience: string;
  mainPain: string;
  whatsappNumber: string;
  dailyBudget: string;
  creatives: string;
}

const STEP_TITLES = {
  1: "Informações do Negócio",
  2: "Dados Financeiros",
  3: "Público-Alvo",
  4: "Recursos e Orçamento",
};

const STEP_DESCRIPTIONS = {
  1: "Comece nos contando sobre seu negócio e objetivos",
  2: "Informações financeiras para otimizar sua campanha",
  3: "Defina seu público-alvo ideal",
  4: "Recursos disponíveis e orçamento",
};

export default function ConsultationNew() {
  const [, navigate] = useLocation();
  const [step, setStep] = useState<ConsultationStep>(1);
  const [isLoading, setIsLoading] = useState(false);
  const [data, setData] = useState<ConsultationData>({
    consultationName: "",
    website: "",
    productService: "",
    campaignObjective: "",
    ticketAverage: "",
    profitMargin: "",
    location: "",
    targetAudience: "",
    mainPain: "",
    whatsappNumber: "",
    dailyBudget: "",
    creatives: "",
  });

  const handleInputChange = (field: keyof ConsultationData, value: string) => {
    setData((prev) => ({ ...prev, [field]: value }));
  };

  const validateStep = (): boolean => {
    switch (step) {
      case 1:
        if (!data.consultationName.trim()) {
          toast.error("Digite um nome para a consultoria");
          return false;
        }
        if (!data.website.trim()) {
          toast.error("Digite a URL do seu site");
          return false;
        }
        if (!data.productService.trim()) {
          toast.error("Descreva seu produto ou serviço");
          return false;
        }
        if (!data.campaignObjective) {
          toast.error("Selecione o objetivo da campanha");
          return false;
        }
        return true;
      case 2:
        if (!data.ticketAverage.trim()) {
          toast.error("Digite o ticket médio");
          return false;
        }
        if (!data.profitMargin.trim()) {
          toast.error("Digite a margem de lucro");
          return false;
        }
        return true;
      case 3:
        if (!data.location.trim()) {
          toast.error("Digite a localização do público");
          return false;
        }
        if (!data.targetAudience.trim()) {
          toast.error("Descreva seu público-alvo ideal");
          return false;
        }
        if (!data.mainPain.trim()) {
          toast.error("Descreva a dor principal do seu público");
          return false;
        }
        return true;
      case 4:
        if (!data.dailyBudget.trim()) {
          toast.error("Digite o orçamento diário");
          return false;
        }
        return true;
      default:
        return true;
    }
  };

  const handleNext = () => {
    if (validateStep()) {
      if (step < 4) {
        setStep((step + 1) as ConsultationStep);
      }
    }
  };

  const handlePrev = () => {
    if (step > 1) {
      setStep((step - 1) as ConsultationStep);
    }
  };

  const createConsultation = trpc.consultation.create.useMutation();

  const handleSubmit = async () => {
    if (!validateStep()) return;

    setIsLoading(true);
    try {
      const result = await createConsultation.mutateAsync({
        consultationName: data.consultationName,
        website: data.website,
        productService: data.productService,
        campaignObjective: data.campaignObjective as "sales" | "leads" | "whatsapp",
        ticketAverage: parseFloat(data.ticketAverage),
        profitMargin: parseFloat(data.profitMargin),
        location: data.location,
        targetAudience: data.targetAudience,
        mainPain: data.mainPain,
        whatsappNumber: data.whatsappNumber || undefined,
        dailyBudget: parseFloat(data.dailyBudget),
        creatives: data.creatives || undefined,
      });

      toast.success("Consultoria criada com sucesso!");
      navigate(`/consultation/${result.id}`);
    } catch (error: any) {
      const errorMsg = error?.data?.code === "UNAUTHORIZED" 
        ? "Você precisa estar autenticado"
        : error?.message || "Erro ao criar consultoria";
      toast.error(errorMsg);
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const progress = (step / 4) * 100;

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted py-8">
      <div className="container max-w-2xl">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-elegant text-3xl md:text-4xl font-bold text-foreground mb-2">
            Nova Consultoria
          </h1>
          <p className="text-muted-foreground">
            Preencha os dados abaixo para receber uma estratégia personalizada de Google Ads
          </p>
        </div>

        {/* Progress Bar */}
        <Card className="card-elegant p-6 mb-8">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-elegant text-xl font-bold text-foreground">
                  {STEP_TITLES[step]}
                </h2>
                <p className="text-sm text-muted-foreground mt-1">
                  {STEP_DESCRIPTIONS[step]}
                </p>
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold text-accent">{step}</div>
                <div className="text-xs text-muted-foreground">de 4</div>
              </div>
            </div>
            <Progress value={progress} className="h-2" />
          </div>
        </Card>

        {/* Form Content */}
        <Card className="card-elegant p-8 mb-8">
          <div className="space-y-6">
            {step === 1 && (
              <div className="space-y-6">
                <div>
                  <Label htmlFor="consultationName" className="text-base font-semibold">
                    Nome da Consultoria
                  </Label>
                  <p className="text-xs text-muted-foreground mb-2">
                    Um nome descritivo para identificar esta consultoria
                  </p>
                  <Input
                    id="consultationName"
                    placeholder="Ex: Consultoria E-commerce Moda"
                    value={data.consultationName}
                    onChange={(e) => handleInputChange("consultationName", e.target.value)}
                    className="mt-2"
                  />
                </div>

                <div>
                  <Label htmlFor="website" className="text-base font-semibold">
                    Site ou Página de Vendas
                  </Label>
                  <p className="text-xs text-muted-foreground mb-2">
                    URL completa do seu site ou landing page
                  </p>
                  <Input
                    id="website"
                    placeholder="https://seu-site.com.br"
                    value={data.website}
                    onChange={(e) => handleInputChange("website", e.target.value)}
                    className="mt-2"
                  />
                </div>

                <div>
                  <Label htmlFor="productService" className="text-base font-semibold">
                    Produto ou Serviço
                  </Label>
                  <p className="text-xs text-muted-foreground mb-2">
                    Descreva brevemente o que você vende
                  </p>
                  <Textarea
                    id="productService"
                    placeholder="Ex: Vendemos roupas de moda feminina de alta qualidade..."
                    value={data.productService}
                    onChange={(e) => handleInputChange("productService", e.target.value)}
                    className="mt-2 min-h-24"
                  />
                </div>

                <div>
                  <Label className="text-base font-semibold mb-3 block">
                    Objetivo Principal da Campanha
                  </Label>
                  <RadioGroup
                    value={data.campaignObjective}
                    onValueChange={(value) =>
                      handleInputChange("campaignObjective", value)
                    }
                  >
                    <div className="flex items-center space-x-2 p-3 rounded-lg border border-border hover:bg-muted/50 cursor-pointer">
                      <RadioGroupItem value="sales" id="sales" />
                      <Label htmlFor="sales" className="cursor-pointer flex-1">
                        <div className="font-semibold">Vendas</div>
                        <div className="text-xs text-muted-foreground">
                          Vender produtos/serviços diretamente
                        </div>
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2 p-3 rounded-lg border border-border hover:bg-muted/50 cursor-pointer">
                      <RadioGroupItem value="leads" id="leads" />
                      <Label htmlFor="leads" className="cursor-pointer flex-1">
                        <div className="font-semibold">Leads</div>
                        <div className="text-xs text-muted-foreground">
                          Capturar contatos interessados
                        </div>
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2 p-3 rounded-lg border border-border hover:bg-muted/50 cursor-pointer">
                      <RadioGroupItem value="whatsapp" id="whatsapp" />
                      <Label htmlFor="whatsapp" className="cursor-pointer flex-1">
                        <div className="font-semibold">WhatsApp</div>
                        <div className="text-xs text-muted-foreground">
                          Direcionar para conversa no WhatsApp
                        </div>
                      </Label>
                    </div>
                  </RadioGroup>
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-6">
                <div>
                  <Label htmlFor="ticketAverage" className="text-base font-semibold">
                    Ticket Médio (R$)
                  </Label>
                  <p className="text-xs text-muted-foreground mb-2">
                    Valor médio de cada venda
                  </p>
                  <Input
                    id="ticketAverage"
                    type="number"
                    placeholder="500"
                    value={data.ticketAverage}
                    onChange={(e) => handleInputChange("ticketAverage", e.target.value)}
                    className="mt-2"
                  />
                </div>

                <div>
                  <Label htmlFor="profitMargin" className="text-base font-semibold">
                    Margem de Lucro (%)
                  </Label>
                  <p className="text-xs text-muted-foreground mb-2">
                    Percentual de lucro em cada venda
                  </p>
                  <Input
                    id="profitMargin"
                    type="number"
                    placeholder="30"
                    value={data.profitMargin}
                    onChange={(e) => handleInputChange("profitMargin", e.target.value)}
                    className="mt-2"
                  />
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-6">
                <div>
                  <Label htmlFor="location" className="text-base font-semibold">
                    Localização do Público-Alvo
                  </Label>
                  <p className="text-xs text-muted-foreground mb-2">
                    Cidades, estados ou regiões
                  </p>
                  <Input
                    id="location"
                    placeholder="São Paulo, Rio de Janeiro"
                    value={data.location}
                    onChange={(e) => handleInputChange("location", e.target.value)}
                    className="mt-2"
                  />
                </div>

                <div>
                  <Label htmlFor="targetAudience" className="text-base font-semibold">
                    Público-Alvo Ideal
                  </Label>
                  <p className="text-xs text-muted-foreground mb-2">
                    Descreva quem é seu cliente ideal
                  </p>
                  <Textarea
                    id="targetAudience"
                    placeholder="Ex: Mulheres de 25-45 anos, profissionais, renda média..."
                    value={data.targetAudience}
                    onChange={(e) => handleInputChange("targetAudience", e.target.value)}
                    className="mt-2 min-h-24"
                  />
                </div>

                <div>
                  <Label htmlFor="mainPain" className="text-base font-semibold">
                    Dor Principal do Público
                  </Label>
                  <p className="text-xs text-muted-foreground mb-2">
                    Qual é o principal problema que você resolve?
                  </p>
                  <Textarea
                    id="mainPain"
                    placeholder="Ex: Falta de opções de moda de qualidade acessível..."
                    value={data.mainPain}
                    onChange={(e) => handleInputChange("mainPain", e.target.value)}
                    className="mt-2 min-h-24"
                  />
                </div>
              </div>
            )}

            {step === 4 && (
              <div className="space-y-6">
                <div>
                  <Label htmlFor="dailyBudget" className="text-base font-semibold">
                    Orçamento Diário (R$)
                  </Label>
                  <p className="text-xs text-muted-foreground mb-2">
                    Quanto você quer gastar por dia em Google Ads
                  </p>
                  <Input
                    id="dailyBudget"
                    type="number"
                    placeholder="100"
                    value={data.dailyBudget}
                    onChange={(e) => handleInputChange("dailyBudget", e.target.value)}
                    className="mt-2"
                  />
                </div>

                <div>
                  <Label htmlFor="whatsappNumber" className="text-base font-semibold">
                    Número do WhatsApp (Opcional)
                  </Label>
                  <p className="text-xs text-muted-foreground mb-2">
                    Se o objetivo é WhatsApp, informe o número
                  </p>
                  <Input
                    id="whatsappNumber"
                    placeholder="11999999999"
                    value={data.whatsappNumber}
                    onChange={(e) => handleInputChange("whatsappNumber", e.target.value)}
                    className="mt-2"
                  />
                </div>

                <div>
                  <Label htmlFor="creatives" className="text-base font-semibold">
                    Recursos Disponíveis (Opcional)
                  </Label>
                  <p className="text-xs text-muted-foreground mb-2">
                    Fotos, vídeos ou outros recursos que você tem
                  </p>
                  <Textarea
                    id="creatives"
                    placeholder="Ex: Temos 50 fotos de produtos, 5 vídeos..."
                    value={data.creatives}
                    onChange={(e) => handleInputChange("creatives", e.target.value)}
                    className="mt-2 min-h-20"
                  />
                </div>
              </div>
            )}
          </div>
        </Card>

        {/* Navigation */}
        <div className="flex gap-4">
          <Button
            variant="outline"
            onClick={handlePrev}
            disabled={step === 1 || isLoading}
            className="flex-1"
          >
            <ChevronLeft className="w-4 h-4 mr-2" />
            Anterior
          </Button>

          {step < 4 ? (
            <Button onClick={handleNext} disabled={isLoading} className="flex-1">
              Próximo
              <ChevronRight className="w-4 h-4 ml-2" />
            </Button>
          ) : (
            <Button onClick={handleSubmit} disabled={isLoading} className="flex-1">
              {isLoading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              {isLoading ? "Gerando Estratégia..." : "Gerar Estratégia"}
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
