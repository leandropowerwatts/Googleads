import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowLeft, Download, Share2, Loader2 } from "lucide-react";
import { Link, useRoute } from "wouter";
import { useState } from "react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { GoogleAdsGuide } from "@/components/GoogleAdsGuide";

export default function ConsultationDetail() {
  const [, params] = useRoute("/consultation/:id");
  const [isExporting, setIsExporting] = useState(false);

  const consultationId = params?.id ? parseInt(params.id) : null;

  // Fetch consultation data
  const { data: consultation, isLoading } = trpc.consultation.getById.useQuery(
    { id: consultationId! },
    { enabled: !!consultationId }
  );

  const exportPDF = trpc.consultation.exportPDF.useMutation();

  const handleExportPDF = async () => {
    if (!consultationId) return;

    try {
      const result = await exportPDF.mutateAsync({ id: consultationId });
      // Create a blob from the base64 string
      const binaryString = atob(result.buffer);
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      const blob = new Blob([bytes], { type: "application/pdf" });

      // Create download link
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = result.filename;
      document.body.appendChild(a);
      a.click();
      
      // Cleanup: remove element safely with timeout to ensure download completes
      setTimeout(() => {
        if (a.parentNode === document.body) {
          document.body.removeChild(a);
        }
        window.URL.revokeObjectURL(url);
      }, 100);

      toast.success("Relatório exportado com sucesso!");
    } catch (error: any) {
      toast.error(error.message || "Erro ao exportar relatório");
      console.error(error);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-accent mx-auto mb-4" />
          <p className="text-muted-foreground">Carregando consultoria...</p>
        </div>
      </div>
    );
  }

  if (!consultation) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted flex items-center justify-center">
        <Card className="card-elegant p-8 text-center max-w-md">
          <h2 className="text-elegant text-2xl font-bold text-foreground mb-4">
            Consultoria não encontrada
          </h2>
          <p className="text-muted-foreground mb-6">
            A consultoria que você está procurando não existe ou foi deletada.
          </p>
          <Link href="/dashboard">
            <Button className="w-full">Voltar ao Dashboard</Button>
          </Link>
        </Card>
      </div>
    );
  }

  const strategy = consultation.strategy ? (typeof consultation.strategy === 'string' ? JSON.parse(consultation.strategy) : consultation.strategy) : null;
  const diagnosis = consultation.diagnosis ? (typeof consultation.diagnosis === 'string' ? JSON.parse(consultation.diagnosis) : consultation.diagnosis) : null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-card/80 backdrop-blur-md border-b border-border">
        <div className="container flex items-center justify-between h-16">
          <Link href="/dashboard">
            <div className="flex items-center gap-2 cursor-pointer hover:opacity-80 transition-opacity">
              <ArrowLeft className="w-5 h-5 text-accent" />
              <span className="text-elegant text-lg font-bold text-foreground">Voltar</span>
            </div>
          </Link>
          <div className="flex items-center gap-4">
            <Button variant="outline" size="sm">
              <Share2 className="w-4 h-4 mr-2" />
              Compartilhar
            </Button>
            <Button onClick={handleExportPDF} disabled={exportPDF.isPending} size="sm">
              {exportPDF.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Exportando...
                </>
              ) : (
                <>
                  <Download className="w-4 h-4 mr-2" />
                  Exportar PDF
                </>
              )}
            </Button>
          </div>
        </div>
      </nav>

      <div className="container py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-elegant text-4xl font-bold text-foreground mb-2">
            {consultation.consultationName}
          </h1>
          <p className="text-muted-foreground">
            Consultoria de Google Ads - Gerada em{" "}
            {new Date(consultation.createdAt).toLocaleDateString("pt-BR", {
              year: "numeric",
              month: "long",
              day: "numeric",
            })}
          </p>
        </div>

        {/* Diagnosis Card */}
        <Card className="card-elegant p-8 mb-8 border-accent/20 bg-gradient-to-br from-card to-accent/5">
          <h2 className="text-elegant text-2xl font-bold text-foreground mb-4">
            Diagnóstico Estratégico
          </h2>
          <p className="text-muted-foreground leading-relaxed">
            {diagnosis?.explanation ||
              "Análise estratégica do seu negócio para otimizar campanhas de Google Ads."}
          </p>
        </Card>

        {/* Tabs */}
        {strategy ? (
          <Tabs defaultValue="structure" className="space-y-6">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="guide">📍 Guia Visual</TabsTrigger>
              <TabsTrigger value="structure">Estrutura</TabsTrigger>
              <TabsTrigger value="keywords">Palavras-chave</TabsTrigger>
              <TabsTrigger value="ads">Anúncios</TabsTrigger>
              <TabsTrigger value="extensions">Extensões</TabsTrigger>
            </TabsList>

            {/* Guide Tab */}
            <TabsContent value="guide" className="space-y-6">
              <GoogleAdsGuide strategy={strategy} consultation={consultation} />
            </TabsContent>

            {/* Structure Tab */}
            <TabsContent value="structure" className="space-y-6">
              <Card className="card-elegant p-8">
                <h3 className="text-elegant text-2xl font-bold text-foreground mb-6">
                  Estrutura Recomendada da Campanha
                </h3>

                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="border-b border-border pb-4">
                      <p className="text-sm text-muted-foreground mb-1">Tipo de Campanha</p>
                      <p className="text-lg font-semibold text-foreground">
                        {strategy.campaignType || "Search"}
                      </p>
                    </div>
                    <div className="border-b border-border pb-4">
                      <p className="text-sm text-muted-foreground mb-1">Estratégia de Lance</p>
                      <p className="text-lg font-semibold text-foreground">
                        {strategy.bidStrategy || "Maximizar Conversões"}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Orçamento Diário</p>
                      <p className="text-lg font-semibold text-foreground">
                        R$ {(strategy.dailyBudget || consultation.dailyBudget).toFixed(2)}
                      </p>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="border-b border-border pb-4">
                      <p className="text-sm text-muted-foreground mb-1">Número de Campanhas</p>
                      <p className="text-lg font-semibold text-foreground">
                        {strategy.numberOfCampaigns || 2}
                      </p>
                    </div>
                    <div className="border-b border-border pb-4">
                      <p className="text-sm text-muted-foreground mb-1">Grupos de Anúncios</p>
                      <p className="text-lg font-semibold text-foreground">
                        {strategy.numberOfAdGroups || 6}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Correspondência de Palavras</p>
                      <p className="text-lg font-semibold text-foreground">
                        {strategy.keywordMatch || "Correspondência Ampla Modificada"}
                      </p>
                    </div>
                  </div>
                </div>
              </Card>
            </TabsContent>

            {/* Keywords Tab */}
            <TabsContent value="keywords" className="space-y-6">
              <Card className="card-elegant p-8">
                <h3 className="text-elegant text-2xl font-bold text-foreground mb-6">
                  Palavras-Chave Recomendadas
                </h3>

                <div className="space-y-8">
                  <div>
                    <h4 className="font-semibold text-foreground mb-4">
                      Palavras-Chave Principais (Fundo de Funil)
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {(strategy.primaryKeywords || []).map((keyword: string, idx: number) => (
                        <div
                          key={idx}
                          className="bg-accent/10 border border-accent/30 rounded-full px-4 py-2 text-sm text-foreground"
                        >
                          {keyword}
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="font-semibold text-foreground mb-4">Palavras-Chave Secundárias</h4>
                    <div className="flex flex-wrap gap-2">
                      {(strategy.secondaryKeywords || []).map((keyword: string, idx: number) => (
                        <div
                          key={idx}
                          className="bg-muted border border-border rounded-full px-4 py-2 text-sm text-foreground"
                        >
                          {keyword}
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="font-semibold text-foreground mb-4 text-destructive">
                      Palavras-Chave Negativas (Evitar)
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {(strategy.negativeKeywords || []).map((keyword: string, idx: number) => (
                        <div
                          key={idx}
                          className="bg-destructive/10 border border-destructive/30 rounded-full px-4 py-2 text-sm text-destructive"
                        >
                          {keyword}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </Card>
            </TabsContent>

            {/* Ads Tab */}
            <TabsContent value="ads" className="space-y-6">
              <Card className="card-elegant p-8">
                <h3 className="text-elegant text-2xl font-bold text-foreground mb-6">
                  Anúncios Recomendados
                </h3>

                <div className="space-y-8">
                  <div>
                    <h4 className="font-semibold text-foreground mb-4">Títulos de Anúncios</h4>
                    <div className="space-y-3">
                      {(strategy.adTitles || []).map((title: string, idx: number) => (
                        <div key={idx} className="bg-muted p-4 rounded-lg border border-border">
                          <p className="text-foreground">{title}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="font-semibold text-foreground mb-4">Descrições de Anúncios</h4>
                    <div className="space-y-3">
                      {(strategy.adDescriptions || []).map((desc: string, idx: number) => (
                        <div key={idx} className="bg-muted p-4 rounded-lg border border-border">
                          <p className="text-foreground">{desc}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="font-semibold text-foreground mb-4">Chamadas para Ação (CTA)</h4>
                    <div className="flex flex-wrap gap-2">
                      {(strategy.ctas || []).map((cta: string, idx: number) => (
                        <div
                          key={idx}
                          className="bg-accent/10 border border-accent/30 rounded-lg px-4 py-2 text-sm text-foreground"
                        >
                          {cta}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </Card>
            </TabsContent>

            {/* Extensions Tab */}
            <TabsContent value="extensions" className="space-y-6">
              <Card className="card-elegant p-8">
                <h3 className="text-elegant text-2xl font-bold text-foreground mb-6">
                  Extensões Recomendadas
                </h3>

                <div className="space-y-3">
                  {(strategy.extensions || []).map((ext: string, idx: number) => (
                    <div key={idx} className="bg-muted p-4 rounded-lg border border-border">
                      <p className="text-foreground">{ext}</p>
                    </div>
                  ))}
                </div>
              </Card>
            </TabsContent>
          </Tabs>
        ) : (
          <Card className="card-elegant p-8 text-center">
            <p className="text-muted-foreground mb-4">
              Estratégia ainda não foi gerada. Por favor, aguarde...
            </p>
          </Card>
        )}
      </div>
    </div>
  );
}
