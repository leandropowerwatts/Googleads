import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowRight, BarChart3, Lightbulb, Zap, CheckCircle2 } from "lucide-react";
import { getLoginUrl } from "@/const";
import { Link } from "wouter";

export default function Home() {
  const { user, isAuthenticated } = useAuth();

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-card/80 backdrop-blur-md border-b border-border">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-accent flex items-center justify-center">
              <span className="text-white font-bold text-lg">GA</span>
            </div>
            <span className="text-elegant text-xl font-bold text-foreground">Google Ads Expert</span>
          </div>
          <div className="flex items-center gap-4">
            {isAuthenticated ? (
              <div className="flex items-center gap-4">
                <span className="text-sm text-muted-foreground">Bem-vindo, {user?.name}</span>
                <Link href="/dashboard">
                  <Button variant="default" size="sm">
                    Dashboard
                  </Button>
                </Link>
              </div>
            ) : (
              <a href={getLoginUrl()}>
                <Button variant="default" size="sm">
                  Entrar
                </Button>
              </a>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="container py-20 md:py-32">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <div className="space-y-4">
              <h1 className="text-elegant text-4xl md:text-5xl lg:text-6xl font-bold leading-tight text-foreground">
                Consultoria de Google Ads com{" "}
                <span className="bg-gradient-to-r from-accent to-accent/70 bg-clip-text text-transparent">
                  IA Especializada
                </span>
              </h1>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Transforme suas campanhas de tráfego pago em máquinas de lucro. Receba estratégias personalizadas baseadas em diagnóstico profundo do seu negócio.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              {isAuthenticated ? (
                <>
                  <Link href="/consultation/new">
                    <Button size="lg" className="w-full sm:w-auto">
                      Iniciar Consultoria <ArrowRight className="ml-2 w-4 h-4" />
                    </Button>
                  </Link>
                  <Link href="/dashboard">
                    <Button size="lg" variant="outline" className="w-full sm:w-auto">
                      Ver Histórico
                    </Button>
                  </Link>
                </>
              ) : (
                <a href={getLoginUrl()} className="w-full sm:w-auto">
                  <Button size="lg" className="w-full">
                    Começar Agora <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                </a>
              )}
            </div>
          </div>

          <div className="hidden md:block">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-accent/20 to-accent/5 rounded-2xl blur-3xl"></div>
              <Card className="relative p-8 card-elegant">
                <div className="space-y-6">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center flex-shrink-0">
                      <Lightbulb className="w-6 h-6 text-accent" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground">Diagnóstico Inteligente</h3>
                      <p className="text-sm text-muted-foreground mt-1">Análise profunda do seu negócio</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center flex-shrink-0">
                      <Zap className="w-6 h-6 text-accent" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground">Estratégia Personalizada</h3>
                      <p className="text-sm text-muted-foreground mt-1">Recomendações específicas para seu caso</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center flex-shrink-0">
                      <BarChart3 className="w-6 h-6 text-accent" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground">Resultados Mensuráveis</h3>
                      <p className="text-sm text-muted-foreground mt-1">Foco em ROAS e ROI</p>
                    </div>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-card border-y border-border py-20">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-elegant text-3xl md:text-4xl font-bold text-foreground mb-4">
              Como Funciona
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Um processo estruturado em 8 etapas que transforma dados em estratégia lucrativa
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-6">
            {[
              { number: "1", title: "Briefing", desc: "Coleta de dados do seu negócio" },
              { number: "2", title: "Diagnóstico", desc: "Análise estratégica profunda" },
              { number: "3", title: "Estrutura", desc: "Definição da campanha ideal" },
              { number: "4", title: "Palavras-chave", desc: "Seleção especializada" },
              { number: "5", title: "Anúncios", desc: "Criação de textos otimizados" },
              { number: "6", title: "Guia", desc: "Instruções passo a passo" },
              { number: "7", title: "Validação", desc: "Checklist de especialista" },
              { number: "8", title: "Otimização", desc: "Consultoria contínua" },
            ].map((step, idx) => (
              <Card key={idx} className="card-elegant p-6 text-center hover:border-accent/50 transition-colors">
                <div className="w-12 h-12 rounded-full bg-gradient-accent flex items-center justify-center mx-auto mb-4">
                  <span className="text-white font-bold text-lg">{step.number}</span>
                </div>
                <h3 className="font-semibold text-foreground mb-2">{step.title}</h3>
                <p className="text-sm text-muted-foreground">{step.desc}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="container py-20">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <h2 className="text-elegant text-3xl md:text-4xl font-bold text-foreground">
              Benefícios Comprovados
            </h2>
            <div className="space-y-4">
              {[
                "Campanhas estruturadas com base em diagnóstico profundo",
                "Redução de desperdício de orçamento em cliques inúteis",
                "Aumento significativo de conversões e ROAS",
                "Estratégia personalizada para seu tipo de negócio",
                "Palavras-chave otimizadas para intenção de compra",
                "Relatórios detalhados e exportáveis em PDF",
              ].map((benefit, idx) => (
                <div key={idx} className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-accent flex-shrink-0 mt-1" />
                  <span className="text-muted-foreground">{benefit}</span>
                </div>
              ))}
            </div>
          </div>

          <Card className="card-elegant p-8">
            <div className="space-y-8">
              <div className="border-b border-border pb-6">
                <div className="text-4xl font-bold text-accent mb-2">+300%</div>
                <p className="text-muted-foreground">Melhoria média em ROAS</p>
              </div>
              <div className="border-b border-border pb-6">
                <div className="text-4xl font-bold text-accent mb-2">-45%</div>
                <p className="text-muted-foreground">Redução em CAC</p>
              </div>
              <div>
                <div className="text-4xl font-bold text-accent mb-2">10+</div>
                <p className="text-muted-foreground">Anos de experiência consolidada</p>
              </div>
            </div>
          </Card>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-accent py-16 md:py-20">
        <div className="container text-center">
          <h2 className="text-elegant text-3xl md:text-4xl font-bold text-white mb-4">
            Pronto para Transformar suas Campanhas?
          </h2>
          <p className="text-white/90 max-w-2xl mx-auto mb-8">
            Comece sua consultoria gratuita agora e receba uma estratégia personalizada em minutos
          </p>
          {isAuthenticated ? (
            <Link href="/consultation/new">
              <Button size="lg" variant="secondary">
                Iniciar Consultoria <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
            </Link>
          ) : (
            <a href={getLoginUrl()}>
              <Button size="lg" variant="secondary">
                Começar Agora <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
            </a>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-8">
        <div className="container text-center text-sm text-muted-foreground">
          <p>© 2026 Google Ads Expert System. Todos os direitos reservados.</p>
        </div>
      </footer>
    </div>
  );
}
