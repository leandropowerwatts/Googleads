import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { Plus, Search, Eye, Download, Trash2, Calendar, Loader2 } from "lucide-react";
import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

const STATUS_LABELS = {
  in_progress: "Em Progresso",
  completed: "Concluída",
  archived: "Arquivada",
};

const STATUS_COLORS = {
  in_progress: "bg-blue-100 text-blue-800",
  completed: "bg-green-100 text-green-800",
  archived: "bg-gray-100 text-gray-800",
};

const OBJECTIVE_LABELS = {
  sales: "Vendas",
  leads: "Leads",
  whatsapp: "WhatsApp",
};

export default function Dashboard() {
  const { user, isAuthenticated } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");
  const [deletingId, setDeletingId] = useState<number | null>(null);

  // Fetch consultations
  const { data: consultations = [], isLoading, refetch } = trpc.consultation.list.useQuery();
  const deleteConsultation = trpc.consultation.delete.useMutation();
  const exportPDF = trpc.consultation.exportPDF.useMutation();

  const filteredConsultations = consultations.filter((c) =>
    c.consultationName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleDelete = async (id: number) => {
    if (!confirm("Tem certeza que deseja deletar esta consultoria?")) return;

    setDeletingId(id);
    try {
      await deleteConsultation.mutateAsync({ id });
      toast.success("Consultoria deletada com sucesso!");
      refetch();
    } catch (error: any) {
      toast.error(error.message || "Erro ao deletar consultoria");
      console.error(error);
    } finally {
      setDeletingId(null);
    }
  };

  const handleExport = async (id: number) => {
    try {
      const result = await exportPDF.mutateAsync({ id });
      // Create a blob from the base64 string
      const binaryString = atob(result.buffer);
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      const blob = new Blob([bytes], { type: "application/pdf" });

      // Create download link
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = result.filename;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      toast.success("Relatório exportado com sucesso!");
    } catch (error: any) {
      toast.error(error.message || "Erro ao exportar relatório");
      console.error(error);
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted flex items-center justify-center">
        <Card className="card-elegant p-8 text-center max-w-md">
          <h2 className="text-elegant text-2xl font-bold text-foreground mb-4">
            Acesso Restrito
          </h2>
          <p className="text-muted-foreground mb-6">
            Você precisa estar autenticado para acessar o dashboard
          </p>
          <Link href="/">
            <Button className="w-full">Voltar para Home</Button>
          </Link>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-card/80 backdrop-blur-md border-b border-border">
        <div className="container flex items-center justify-between h-16">
          <Link href="/">
            <div className="flex items-center gap-2 cursor-pointer">
              <div className="w-8 h-8 rounded-lg bg-gradient-accent flex items-center justify-center">
                <span className="text-white font-bold text-lg">GA</span>
              </div>
              <span className="text-elegant text-xl font-bold text-foreground">
                Google Ads Expert
              </span>
            </div>
          </Link>
          <div className="flex items-center gap-4">
            <span className="text-sm text-muted-foreground">{user?.name}</span>
            <Link href="/consultation/new">
              <Button size="sm">
                <Plus className="w-4 h-4 mr-2" />
                Nova Consultoria
              </Button>
            </Link>
          </div>
        </div>
      </nav>

      <div className="container py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-elegant text-3xl md:text-4xl font-bold text-foreground mb-2">
            Dashboard
          </h1>
          <p className="text-muted-foreground">
            Gerencie e acompanhe suas consultorias de Google Ads
          </p>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card className="card-elegant p-6">
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">Total de Consultorias</p>
              <div className="text-3xl font-bold text-accent">{consultations.length}</div>
            </div>
          </Card>
          <Card className="card-elegant p-6">
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">Em Progresso</p>
              <div className="text-3xl font-bold text-accent">
                {consultations.filter((c) => c.status === "in_progress").length}
              </div>
            </div>
          </Card>
          <Card className="card-elegant p-6">
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">Concluídas</p>
              <div className="text-3xl font-bold text-accent">
                {consultations.filter((c) => c.status === "completed").length}
              </div>
            </div>
          </Card>
        </div>

        {/* Search and Filter */}
        <Card className="card-elegant p-6 mb-8">
          <div className="flex gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Buscar consultoria..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Link href="/consultation/new">
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                Nova Consultoria
              </Button>
            </Link>
          </div>
        </Card>

        {/* Consultations List */}
        <div className="space-y-4">
          {isLoading ? (
            <Card className="card-elegant p-12 text-center">
              <Loader2 className="w-8 h-8 animate-spin mx-auto text-accent mb-4" />
              <p className="text-muted-foreground">Carregando consultorias...</p>
            </Card>
          ) : filteredConsultations.length > 0 ? (
            filteredConsultations.map((consultation) => (
              <Card
                key={consultation.id}
                className="card-elegant p-6 hover:border-accent/50 transition-colors"
              >
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-elegant text-lg font-bold text-foreground">
                        {consultation.consultationName}
                      </h3>
                      <Badge className={`${STATUS_COLORS[consultation.status]}`}>
                        {STATUS_LABELS[consultation.status]}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-3">
                      {consultation.productService}
                    </p>
                    <div className="flex flex-wrap gap-4 text-xs text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        {new Date(consultation.createdAt).toLocaleDateString("pt-BR")}
                      </div>
                      <Badge variant="outline" className="text-xs">
                        {OBJECTIVE_LABELS[consultation.campaignObjective as keyof typeof OBJECTIVE_LABELS]}
                      </Badge>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Link href={`/consultation/${consultation.id}`}>
                      <Button variant="outline" size="sm">
                        <Eye className="w-4 h-4 mr-2" />
                        Ver Detalhes
                      </Button>
                    </Link>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleExport(consultation.id)}
                      disabled={exportPDF.isPending}
                    >
                      {exportPDF.isPending ? (
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      ) : (
                        <Download className="w-4 h-4 mr-2" />
                      )}
                      Exportar
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-destructive hover:text-destructive"
                      onClick={() => handleDelete(consultation.id)}
                      disabled={deletingId === consultation.id}
                    >
                      {deletingId === consultation.id ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <Trash2 className="w-4 h-4" />
                      )}
                    </Button>
                  </div>
                </div>
              </Card>
            ))
          ) : (
            <Card className="card-elegant p-12 text-center">
              <p className="text-muted-foreground mb-4">
                Nenhuma consultoria encontrada
              </p>
              <Link href="/consultation/new">
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Criar Primeira Consultoria
                </Button>
              </Link>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
