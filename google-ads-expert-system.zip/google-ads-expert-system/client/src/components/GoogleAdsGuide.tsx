import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChevronRight, Copy, Download } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

interface GuideStep {
  id: number;
  title: string;
  description: string;
  image: string;
  fields: {
    label: string;
    value: string;
    instruction: string;
  }[];
  tips: string[];
}

interface GoogleAdsGuideProps {
  strategy: any;
  consultation: any;
}

export function GoogleAdsGuide({ strategy, consultation }: GoogleAdsGuideProps) {
  const [currentStep, setCurrentStep] = useState(0);

  const steps: GuideStep[] = [
    {
      id: 1,
      title: "1. Criar Campanha",
      description: "Configure os dados básicos da sua campanha no Google Ads",
      image: "https://private-us-east-1.manuscdn.com/sessionFile/RAsfhDMNACen35F5QXyUgD/sandbox/OssXGpdl7YcaHeWlP2TOtK-img-1_1770745342000_na1fn_Z29vZ2xlLWFkcy1zdGVwMS1jYW1wYWlnbg.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvUkFzZmhETU5BQ2VuMzVGNVFYeVVnRC9zYW5kYm94L09zc1hHcGRsN1ljYUhlV2xQMlRPdEstaW1nLTFfMTc3MDc0NTM0MjAwMF9uYTFmbl9aMjl2WjJ4bExXRmtjeTF6ZEdWd01TMWpZVzF3WVdsbmJnLnBuZz94LW9zcy1wcm9jZXNzPWltYWdlL3Jlc2l6ZSx3XzE5MjAsaF8xOTIwL2Zvcm1hdCx3ZWJwL3F1YWxpdHkscV84MCIsIkNvbmRpdGlvbiI6eyJEYXRlTGVzc1RoYW4iOnsiQVdTOkVwb2NoVGltZSI6MTc5ODc2MTYwMH19fV19&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=dKgCn4YYK78Sbr2esynu8XyxY042scA~nwdhmJJORux8lmijPTsvG7kVLTgPe-~Sn9F95xleGtGpFsRfdbqTvF0VGEkqVy3e70aSoeY46vZ8xZhK6qUWKlj8UCNxk~ejy3SoKVQdVBBO4UVHGdErNIyTHNYSQ~jnPL5yUy~o2nRLlGkyT5YcCVZWpKNuFjrqvkiGBc6LLQ3t1loUqe3y0wMBTbAuxDXxPftTPLHDpU144LFVEUQ9knp2LBFwmY1p8ilcjzU7zhcp4kpV6RPXW8nohFxp6cnSYfoTsOT6nQ6qQzQ2YndcVBd95v~P~jQfl0wIq-thY6ZnqIIwGHT~nw__",
      fields: [
        {
          label: "Nome da Campanha",
          value: `${consultation.consultationName} - ${strategy.campaignType}`,
          instruction: "Cole este nome exatamente como está no campo 'Nome da campanha'",
        },
        {
          label: "Tipo de Campanha",
          value: strategy.campaignType || "Search",
          instruction: "Selecione este tipo na lista de tipos de campanha",
        },
        {
          label: "Localização do Público",
          value: consultation.location,
          instruction: "Adicione esta localização em 'Localizações'",
        },
      ],
      tips: [
        "Use um nome descritivo para identificar facilmente a campanha",
        "O tipo de campanha já foi recomendado pela IA baseado em sua análise",
        "Você pode adicionar múltiplas localizações se necessário",
      ],
    },
    {
      id: 2,
      title: "2. Configurar Orçamento",
      description: "Defina o orçamento e a estratégia de lance",
      image: "https://private-us-east-1.manuscdn.com/sessionFile/RAsfhDMNACen35F5QXyUgD/sandbox/OssXGpdl7YcaHeWlP2TOtK-img-2_1770745342000_na1fn_Z29vZ2xlLWFkcy1zdGVwMi1idWRnZXQ.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvUkFzZmhETU5BQ2VuMzVGNVFYeVVnRC9zYW5kYm94L09zc1hHcGRsN1ljYUhlV2xQMlRPdEstaW1nLTJfMTc3MDc0NTM0MjAwMF9uYTFmbl9aMjl2WjJ4bExXRmtjeTF6ZEdWd01pMWlkV1JuWlhRLnBuZz94LW9zcy1wcm9jZXNzPWltYWdlL3Jlc2l6ZSx3XzE5MjAsaF8xOTIwL2Zvcm1hdCx3ZWJwL3F1YWxpdHkscV84MCIsIkNvbmRpdGlvbiI6eyJEYXRlTGVzc1RoYW4iOnsiQVdTOkVwb2NoVGltZSI6MTc5ODc2MTYwMH19fV19&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=c~uO8Usa5XSEdkB5KMsC0leqzwD2LJawGww~uhRPWvqgA5-HZr6s4mPQ7jRyQ1OGKFFQA1s1JCRChPmjxR~elJ55DrmjpV0hp0ei0NbqHnWvhfeDl8JuYNN5fJg4MuU0vfXOcPVv6JwTqGQgiRaqXDKdJCkiWHia7iKqpDnXp5CieF-GZPHQtJZaoX6WLm2CzAajiH6iTPPlPv3hB3j6Rk5LkWmeGuHVm-MEViGqUukT4vdmGHkV~lkNHhuaX7nqIe0yWa~aKvVR9mozpGQsR5eopUBBquQFDXnCsyOzJxqYB4EysUeO8aNBjA-kCGqzbLTNu8uupEDae8x3MzOaFw__",
      fields: [
        {
          label: "Orçamento Diário",
          value: `R$ ${strategy.dailyBudget?.toFixed(2) || consultation.dailyBudget.toFixed(2)}`,
          instruction: "Digite este valor no campo 'Orçamento diário'",
        },
        {
          label: "Estratégia de Lance",
          value: strategy.bidStrategy || "Maximize Conversions",
          instruction: "Selecione esta estratégia na lista de estratégias de lance",
        },
        {
          label: "Número de Campanhas",
          value: `${strategy.numberOfCampaigns || 1}`,
          instruction: "Você vai criar este número de campanhas separadas",
        },
      ],
      tips: [
        "O orçamento diário foi calculado baseado em sua margem de lucro",
        "A estratégia de lance foi recomendada para maximizar suas conversões",
        "Você pode ajustar o orçamento conforme necessário",
      ],
    },
    {
      id: 3,
      title: "3. Adicionar Palavras-Chave",
      description: "Adicione as palavras-chave recomendadas",
      image: "https://private-us-east-1.manuscdn.com/sessionFile/RAsfhDMNACen35F5QXyUgD/sandbox/OssXGpdl7YcaHeWlP2TOtK-img-3_1770745342000_na1fn_Z29vZ2xlLWFkcy1zdGVwMy1rZXl3b3Jkcw.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvUkFzZmhETU5BQ2VuMzVGNVFYeVVnRC9zYW5kYm94L09zc1hHcGRsN1ljYUhlV2xQMlRPdEstaW1nLTNfMTc3MDc0NTM0MjAwMF9uYTFmbl9aMjl2WjJ4bExXRmtjeTF6ZEdWd015MXJaWGwzYjNKa2N3LnBuZz94LW9zcy1wcm9jZXNzPWltYWdlL3Jlc2l6ZSx3XzE5MjAsaF8xOTIwL2Zvcm1hdCx3ZWJwL3F1YWxpdHkscV84MCIsIkNvbmRpdGlvbiI6eyJEYXRlTGVzc1RoYW4iOnsiQVdTOkVwb2NoVGltZSI6MTc5ODc2MTYwMH19fV19&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=fJrK8UT3Q9btTxn9kb3AJ7Hc00T4hElwPU93FlGEuZ0mojoQ2eMMgfL6B-1mS6Y~yJAz208MunyWqAvQEqvQcxz~Q03qEckcUL8GBNQVHgbvcPsrGqroSAEpxuGVRk5R-sefx8iB2OhnpWJIzfWZ8Endn2x3h1vMPK6eoXRdIhJN4lmiD6ilXQ9gDq2I6YWoTc-4wJPNluRzhI4Nh1zciwLfkYyrWemSmTZHHiHEPfGVWaC3XaP3uM6uyqIRmFdhZhCCB8SwvE4f51eQ7qIkRGw3wRH6YBxrMaS~TMmTOOdhN0SsBz6ZYBNFYdJFFfUEpf8rNc1iFN-a~CxtiATmTw__",
      fields: [
        {
          label: "Palavras-Chave Principais",
          value: (strategy.primaryKeywords || []).join(", "),
          instruction: "Adicione cada uma destas palavras-chave no Google Ads",
        },
        {
          label: "Palavras-Chave Secundárias",
          value: (strategy.secondaryKeywords || []).join(", "),
          instruction: "Adicione estas como palavras-chave secundárias",
        },
        {
          label: "Palavras-Chave Negativas",
          value: (strategy.negativeKeywords || []).join(", "),
          instruction: "Adicione estas como palavras-chave negativas para evitar cliques inúteis",
        },
        {
          label: "Tipo de Correspondência",
          value: strategy.keywordMatch || "Phrase Match",
          instruction: "Use este tipo de correspondência para suas palavras-chave",
        },
      ],
      tips: [
        "Palavras-chave principais têm maior intenção de compra",
        "Palavras-chave negativas evitam gastos com buscas irrelevantes",
        "Comece com correspondência de frase e ajuste conforme necessário",
      ],
    },
    {
      id: 4,
      title: "4. Criar Anúncios",
      description: "Crie os anúncios com os textos recomendados",
      image: "https://private-us-east-1.manuscdn.com/sessionFile/RAsfhDMNACen35F5QXyUgD/sandbox/OssXGpdl7YcaHeWlP2TOtK-img-4_1770745344000_na1fn_Z29vZ2xlLWFkcy1zdGVwNC1hZHM.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvUkFzZmhETU5BQ2VuMzVGNVFYeVVnRC9zYW5kYm94L09zc1hHcGRsN1ljYUhlV2xQMlRPdEstaW1nLTRfMTc3MDc0NTM0NDAwMF9uYTFmbl9aMjl2WjJ4bExXRmtjeTF6ZEdWd05DMWhaSE0ucG5nP3gtb3NzLXByb2Nlc3M9aW1hZ2UvcmVzaXplLHdfMTkyMCxoXzE5MjAvZm9ybWF0LHdlYnAvcXVhbGl0eSxxXzgwIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNzk4NzYxNjAwfX19XX0_&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=JJ20Nu2A63lVl9pjWAbertRNkqOCsh6OwDqJd~BpVJzoT9MqMIGQIZ3CyjenD4qDHRNoQUPxFiQbr9eR5N27DrrEb0zJEtOysFHSZSoxtGTSsBV9a9TvlBaRU8lmXMxbqK4E3yQTP-SJv3px6v14jUUPK1MRE4t5-QJ1Fmi80QiqID8lQBqmb-SeOARfYZjcPfIeS6ydmVMXnIHJ8VtBAbe8DLDl8NNMY2qudL0YOgIUc50WrkqKoxJFn2Oac9WrH1x~r39N7rRBzEXnkL-l1NOcUDwIbQTDng855u85qyHVXEYgZ4pclRLFvziTyo07ZK7u9Ot531gIQiOMKT9Q6Q__",
      fields: [
        {
          label: "Títulos do Anúncio (use 3)",
          value: (strategy.adTitles || []).join(" | "),
          instruction: "Copie cada título e adicione no Google Ads",
        },
        {
          label: "Descrições (use 2)",
          value: (strategy.adDescriptions || []).join(" | "),
          instruction: "Copie cada descrição e adicione no Google Ads",
        },
        {
          label: "URL Final",
          value: consultation.website,
          instruction: "Use este URL como destino final do seu anúncio",
        },
      ],
      tips: [
        "Use todos os 3 títulos para aumentar a relevância",
        "Adicione pelo menos 2 descrições diferentes",
        "Certifique-se de que o URL está correto e acessível",
      ],
    },
    {
      id: 5,
      title: "5. Checklist Final",
      description: "Verifique tudo antes de publicar sua campanha",
      image: "https://private-us-east-1.manuscdn.com/sessionFile/RAsfhDMNACen35F5QXyUgD/sandbox/OssXGpdl7YcaHeWlP2TOtK-img-5_1770745340000_na1fn_Z29vZ2xlLWFkcy1zdGVwNS1jaGVja2xpc3Q.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvUkFzZmhETU5BQ2VuMzVGNVFYeVVnRC9zYW5kYm94L09zc1hHcGRsN1ljYUhlV2xQMlRPdEstaW1nLTVfMTc3MDc0NTM0MDAwMF9uYTFmbl9aMjl2WjJ4bExXRmtjeTF6ZEdWd05TMWphR1ZqYTJ4cGMzUS5wbmc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=cjdA1S-rwtC0QgFLYyRxbDBa~A-BAwYVIoPjwD~hPkBzkNfFfq0NOQyGMyP3mLfrZGxpYbxHMK3~EeqdPOLReiniow3Q~63IcZewnGggIsX4U8fcngFMEzcmoe13XsLWMTKZvGSyo1rqCQZ~--wIVmfEbe8kit-O0UoCQCO0icYiqt2P6JbVJo8JavnWcHjUvy8D1f0uiAMh1T44wNpnO8EAjzNpnQrSN0RWyzGxOAJZXxv3Kv9UpQr4c7BV8bgF12DQQXS2hvbBgT-UAgFRejqpve3man4igwAulmo~-HJx3u5l4I67u8rPrKh1O6gQl5GuDX0e-Na7b45Y9DhC2w__",
      fields: [
        {
          label: "Verificação",
          value: "Pronto para publicar",
          instruction: "Revise todos os itens abaixo",
        },
      ],
      tips: [
        "✅ Nome da campanha está claro e descritivo",
        "✅ Orçamento diário está configurado corretamente",
        "✅ Palavras-chave principais e negativas foram adicionadas",
        "✅ Todos os 3 títulos e 2 descrições foram adicionados",
        "✅ URL final está correto e testado",
        "✅ Extensões foram adicionadas",
        "✅ Localização do público está correta",
      ],
    },
  ];

  const handleCopyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success("Copiado para a área de transferência!");
  };

  const step = steps[currentStep];

  return (
    <div className="space-y-6">
      {/* Progress Indicator */}
      <div className="flex gap-2">
        {steps.map((s, idx) => (
          <button
            key={s.id}
            onClick={() => setCurrentStep(idx)}
            className={`flex-1 h-2 rounded-full transition-all ${
              idx === currentStep
                ? "bg-accent"
                : idx < currentStep
                  ? "bg-green-500"
                  : "bg-muted"
            }`}
          />
        ))}
      </div>

      {/* Step Content */}
      <Card className="card-elegant p-8 border-accent/20">
        <div className="mb-6">
          <h2 className="text-elegant text-3xl font-bold text-foreground mb-2">
            {step.title}
          </h2>
          <p className="text-muted-foreground text-lg">{step.description}</p>
        </div>

        {/* Image */}
        {step.image && (
          <div className="mb-8 rounded-lg overflow-hidden border border-border">
            <img
              src={step.image}
              alt={step.title}
              className="w-full h-auto"
            />
          </div>
        )}

        {/* Fields */}
        <div className="space-y-6 mb-8">
          {step.fields.map((field, idx) => (
            <div
              key={idx}
              className="border border-border rounded-lg p-6 bg-muted/30"
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <p className="text-sm font-semibold text-muted-foreground mb-2">
                    {field.label}
                  </p>
                  <p className="text-foreground font-mono text-sm mb-3 break-words bg-background p-3 rounded border border-border">
                    {field.value}
                  </p>
                  <p className="text-sm text-accent font-semibold">
                    📍 {field.instruction}
                  </p>
                </div>
                {field.value && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleCopyToClipboard(field.value)}
                    className="mt-1 whitespace-nowrap"
                  >
                    <Copy className="w-4 h-4 mr-2" />
                    Copiar
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Tips */}
        <div className="bg-accent/10 border border-accent/30 rounded-lg p-6 mb-8">
          <h3 className="font-semibold text-foreground mb-3">💡 Dicas Importantes</h3>
          <ul className="space-y-2">
            {step.tips.map((tip, idx) => (
              <li key={idx} className="text-sm text-foreground flex gap-2">
                <span className="text-accent">•</span>
                <span>{tip}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Navigation */}
        <div className="flex gap-4 justify-between">
          <Button
            onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
            disabled={currentStep === 0}
            variant="outline"
          >
            ← Anterior
          </Button>

          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            Etapa {currentStep + 1} de {steps.length}
          </div>

          <Button
            onClick={() => setCurrentStep(Math.min(steps.length - 1, currentStep + 1))}
            disabled={currentStep === steps.length - 1}
          >
            Próxima <ChevronRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </Card>

      {/* Download Guide Button */}
      <Button className="w-full" size="lg" variant="outline">
        <Download className="w-4 h-4 mr-2" />
        Baixar Guia Completo em PDF
      </Button>
    </div>
  );
}
